% Script for loading consumption data of industry, agriculture, commercial
% and residential. All data is on a hour sampling. There is one week of
% data.
clc; clear all; close all;

%% Read Industry
% file to read
fileName = 'industry.xlsx';
savePath = '/Users/rasmus/Dropbox/SmartC2Net-Control/benchmark_simulation_framework/matlab/mv_grid/consData/';

season = 'B2:B169'; % B is winter and C is summer 
pIndu = xlsread(fileName,season);
p = pIndu*1000;
saveName = 'induPowerWinter';
curPath = pwd;
cd(savePath);
save(saveName,'p');
cd(curPath);

season = 'C2:C169'; % B is winter and C is summer 
p = xlsread(fileName,season);
p = p*1000;
saveName = 'induPowerSummer';
curPath = pwd;
cd(savePath);
save(saveName,'p');
cd(curPath);

%% Read Agriculture
% file to read
fileName = 'agriculture.xlsx';
savePath = '/Users/rasmus/Dropbox/SmartC2Net-Control/benchmark_simulation_framework/matlab/mv_grid/consData/';

season = 'B2:B169'; % B is winter and C is summer 
p = xlsread(fileName,season);
p = p*1000;
saveName = 'agriPowerWinter';
curPath = pwd;
cd(savePath);
save(saveName,'p');
cd(curPath);

season = 'C2:C169'; % B is winter and C is summer 
p = xlsread(fileName,season);
p = p*1000;
saveName = 'agriPowerSummer';
curPath = pwd;
cd(savePath);
save(saveName,'p');
cd(curPath);

%% Read Commercial
% file to read
fileName = 'commercial.xlsx';
savePath = '/Users/rasmus/Dropbox/SmartC2Net-Control/benchmark_simulation_framework/matlab/mv_grid/consData/';

season = 'B2:B169'; % B is winter and C is summer 
p = xlsread(fileName,season);
p = p*1000;
saveName = 'commPowerWinter';
curPath = pwd;
cd(savePath);
save(saveName,'p');
cd(curPath);

season = 'C2:C169'; % B is winter and C is summer 
p = xlsread(fileName,season);
p = p*1000;
saveName = 'commPowerSummer';
curPath = pwd;
cd(savePath);
save(saveName,'p');
cd(curPath);